package assignments;

public class AnnieSumof2nums {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=4+36;
		System.out.println("Sum of the two given numbers: "+sum);

	}
	

}
