package assignments;

public class AnniePrintName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		System.out.println("Hello");
//		System.out.println("Merin");
		
		System.out.println("Hello" +'\n'+"Merin");
	}

}
