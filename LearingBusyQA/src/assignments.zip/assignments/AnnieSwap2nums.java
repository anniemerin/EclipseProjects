package assignments;

public class AnnieSwap2nums {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=20;
		System.out.println("Value of a before swap: "+a);
		System.out.println("Value of b before swap: "+b);
		int c;
		c=a;
		a=b;
		b=c;
		System.out.println("Value of a after swap: "+a);
		System.out.println("Value of b after swap: "+b);
		

	}

}
